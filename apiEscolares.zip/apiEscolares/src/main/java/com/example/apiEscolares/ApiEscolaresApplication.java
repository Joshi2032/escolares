package com.example.apiEscolares;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiEscolaresApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiEscolaresApplication.class, args);
	}

}
